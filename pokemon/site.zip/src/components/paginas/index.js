import 'index.scss';

export default function Paginas(){
    return(
        <div className='comp-paginas'>
            {props}
        </div>
    )
}