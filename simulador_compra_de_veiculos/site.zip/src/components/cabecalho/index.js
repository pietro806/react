


export default function Cabecalho() {
    return(
        <div>
            <img src='/assets/images/cabecalho.png' />
        </div>
    )
}