import './index.scss';

export default function Cabecalho() {
    return(
        <div className='comp-cabecalho'>
            <img src='/assets/images/logo.png' alt='img'/>
            <img src='/assets/images/txt-logo.png' alt='img'/>
        </div>
    )
}