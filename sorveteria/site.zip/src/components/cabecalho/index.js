import './index.scss';

export default function Cabecalho() {
    return(
        <div className='comp-header'>
            <img src='/assets/images/logo-cabecalho.png' />
            <img src='/assets/images/text-header.png' />
        </div>
    )
}